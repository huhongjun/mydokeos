<?php 
/**
 * This script must be launched from a browser
 */
if(empty($_GET['host']) OR empty($_GET['port']) OR empty($_GET['pass']))
{
	echo "<br />This script is a quick helper to update a Dokeos 1.8.4 or 1.8.5 alpha portal to enable and configure the videoconference tool (version 2.0). If used improperly, this script can SERIOUSLY DAMAGE your Dokeos installation. Please follow the instructions in the installation documentation carefully and have a backup ready! We take no responsibility in case of loss of or damage to your data.<br />\n";
	echo "USAGE: http://yourhost/dokeos/videosetweb.php?host={red5host}&port={red5port}&pass={red5password}<br />\n";
	echo " {host}:   The host name of the videoconference server<br />";
	echo " {port}:   The port of the videoconference server streaming service<br />";
	echo " {pass}:   The password for the videoconference service<br />";
	echo " The following are optional parameters in the case of a 1.8.4, but are mandatory for a 1.8.5 alpha, you can add them with the URL syntax <em>&param=value</em><br />";
	echo " {active}: Whether the videoconference tool links in the courses should be hidden (0) or shown (1) by default (default:1)<br />";
	echo " {complete}: Whether the install should be made from an unpatched 1.8.4 (default:1). For Dokeos 1.8.4, use 1, otherwise use 0<br />";
	exit;
}
require_once(dirname(__FILE__).'/main/inc/global.inc.php');
$host	 	= mysql_real_escape_string($_GET['host']);
$port		= mysql_real_escape_string($_GET['port']);
$pass		= mysql_real_escape_string($_GET['pass']);
$complete = 1;
$link = 1;
if(isset($_GET['active']))
{
	$link		= mysql_real_escape_string($_GET['active']);
}
if(isset($_GET['complete']))
{
	$complete 	= mysql_real_escape_string($_GET['complete']);
}


echo "This script enables the videoconference tool, version 2 in Dokeos 1.8.5<br />" .
	"It inserts the database settings with the ones given as parameters,<br />" .
	"then inserts the videoconference links into each course.<br />\n";

$e_msg = '';
if($complete)
{
	echo "You have requested a complete install from an unpatched 1.8.4. Proceeding...<br />";
	if(update_184())
	{
		echo "Patch succeeded. Proceeding to activation.<br />";
	}
	else
	{
		echo "Patch failed. Halted activation process.<br />";
		exit;
	}
}

$res = update_visio_settings($host,$port,$pass);
if($res == false)
{
	echo "Operation failed<br />";
}
else
{
	echo "Operation succeeded<br />";
}

/**
 * Patch a 1.8.5 or patched 1.8.4 portal to change the videoconference setting 
 * (and possibly activate the videoconference for the first time)
 * @param	string	Server hostname. Default: 'red5.dokeos.com'
 * @param	int		Server port. Default: 1935
 * @param	string	Password for the server to let us use it. Default: ''
 * @param	int		Whether to show (1) or hide (0) new videoconference links in courses. Default 1
 * @return	bool	True on success, false on error.
 */
function update_visio_settings($host='red5.dokeos.com',$port=1935,$pass='',$link=1)
{
	$table = Database::get_main_table(TABLE_MAIN_SETTINGS_CURRENT);
	$sql0 = "UPDATE $table set selected_value = 'true' WHERE variable = 'service_visio' AND subkey = 'active'";
	$res0 = api_sql_query($sql0);
	$sql1 = "UPDATE $table set selected_value = '$host' WHERE variable = 'service_visio' AND subkey = 'visio_host'";
	$res1 = api_sql_query($sql1);
	$sql2 = "UPDATE $table set selected_value = '$port' WHERE variable = 'service_visio' AND subkey = 'visio_port'";
	$res2 = api_sql_query($sql2);
	$sql3 = "UPDATE $table set selected_value = '$pass' WHERE variable = 'service_visio' AND subkey = 'visio_pass'";
	$res3 = api_sql_query($sql3);	

	$link = (int) $link;
	$link = ($link >= 1 ? 1:0);

	// select all the courses and insert the tool inside
	$sql = 'SELECT db_name FROM '.Database::get_main_table(TABLE_MAIN_COURSE);
	$rs = api_sql_query($sql, __FILE__, __LINE__);
	while($row = Database::fetch_array($rs))
	{
		$tool_table = Database::get_course_table(TABLE_TOOL_LIST,$row['db_name']);
		$sql = "SELECT name FROM $tool_table " .
				"WHERE name='".TOOL_VISIO_CONFERENCE."'" .
				" AND link='conference/index.php?type=conference'";
		$res = api_sql_query($sql, __FILE__, __LINE__);
		$num = Database::num_rows($res);
		if($num<1)
		{
			$sql = 'INSERT INTO '.$tool_table.' SET 
					name="'.TOOL_VISIO_CONFERENCE.'",
					link="conference/index.php?type=conference",
					image="visio_meeting.gif",
					visibility="'.$link.'",
					admin="0",
					address="squaregrey.gif",
					target="_self",
					category="interaction"';
			api_sql_query($sql, __FILE__, __LINE__);
		}
		$sql = "SELECT name FROM $tool_table " .
				"WHERE name='".TOOL_VISIO_CLASSROOM."'" .
				" AND link='conference/index.php?type=classroom'";
		$res = api_sql_query($sql, __FILE__, __LINE__);
		$num = Database::num_rows($res);
		if($num<1)
		{
			$sql = 'INSERT INTO '.$tool_table.' SET 
					name="'.TOOL_VISIO_CLASSROOM.'",
					link="conference/index.php?type=classroom",
					image="visio.gif",
					visibility="'.$link.'",
					admin="0",
					address="squaregrey.gif",
					target="_self",
					category="authoring"';
			api_sql_query($sql, __FILE__, __LINE__);
		}
	}
	// update add_course.lib.inc.php
	$path = api_get_path(LIBRARY_PATH).'add_course.lib.inc.php';
	$file = file_get_contents($path);
	if($file === false)
	{
		echo "Could not update add_course.inc.lib.php - please edit the file, remove the two sub-conditions of \"if(api_get_setting('service_visio','active')=='true')\" but leave the two queries as direct children of the active=true condition<br />";
	}
	else
	{
		$file = str_replace("if(api_get_setting('service_visio','visioconference_url'))",'$mycheck = api_get_setting(\'service_visio\',\'visio_host\');if(!empty($mycheck))',$file);
		$file = str_replace("if(api_get_setting('service_visio','visioclassroom_url'))",'$mycheck = api_get_setting(\'service_visio\',\'visio_host\');if(!empty($mycheck))',$file);
	}
	$res = file_put_contents($path,$file);
	if($res === false)
	{
		echo "Could not update add_course.inc.lib.php - please edit the file, remove the two sub-conditions of \"if(api_get_setting('service_visio','active')=='true')\" but leave the two queries as direct children of the active=true condition<br />";
	}
	return $res1 && $res2 && $res3; 
}
/**
 * Patch a classic 1.8.4 portal to enable the *new* videoconference
 */
function update_184()
{
	global $e_msg;
	// select all the courses and insert the tool inside
	$sql = 'SELECT db_name FROM '.Database::get_main_table(TABLE_MAIN_COURSE);
	$rs = api_sql_query($sql, __FILE__, __LINE__);
	while($row = Database::fetch_array($rs))
	{
		$tool_table = Database::get_course_table(TABLE_TOOL_LIST,$row['db_name']);
		$sql = "SELECT id, name FROM $tool_table " .
				" WHERE link LIKE BINARY '%online/online.php%'";
		$res = api_sql_query($sql, __FILE__, __LINE__);
		$num = Database::num_rows($res);
		if($num>0)
		{
			$sqld = "DELETE FROM $tool_table WHERE link LIKE BINARY '%online/online.php%'";
			$resd = api_sql_query($sqld,__FILE__,__LINE__);
		}
	}
	$ts = Database::get_main_table(TABLE_MAIN_SETTINGS_CURRENT);
	$to = Database::get_main_table(TABLE_MAIN_SETTINGS_OPTIONS);
	$sql = "UPDATE settings_current SET variable='service_visio', subkey='active'    , title='VisioEnable' WHERE variable='service_visio' AND subkey='active'";
	$res = api_sql_query($sql);
	if($res === false){$e_msg .= mysql_error($res)."<br />"; return false;}
	$sql = "UPDATE settings_current SET variable='service_visio', subkey='visio_host', title='VisioHost' WHERE variable='service_visio' AND subkey='visio_rtmp_host_local'";
	$res = api_sql_query($sql);
	if($res === false){$e_msg .= mysql_error($res)."<br />"; return false;}
	$sql = "UPDATE settings_current SET variable='service_visio', subkey='visio_port', title='VisioPort' WHERE variable='service_visio' AND subkey='visio_rtmp_port'";
	$res = api_sql_query($sql);
	if($res === false){$e_msg .= mysql_error($res)."<br />"; return false;}
	$sql = "INSERT INTO settings_current (variable, subkey, type, category, selected_value, title, comment, scope, subkeytext) VALUES ('service_visio', 'visio_pass', 'textfield',NULL,'', 'VisioPassword','', NULL, NULL)";
	$res = api_sql_query($sql);
	if($res === false){$e_msg .= mysql_error($res)."<br />"; return false;}
	$sql = "DELETE FROM settings_options WHERE variable = 'visio_rtmp_host_local'";
	$res = api_sql_query($sql);
	if($res === false){$e_msg .= mysql_error($res)."<br />"; return false;}
	$sql = "DELETE FROM settings_current WHERE variable='service_visio' AND subkey='visioconference_url'";
	$res = api_sql_query($sql);
	if($res === false){$e_msg .= mysql_error($res)."<br />"; return false;}
	$sql = "DELETE FROM settings_current WHERE variable='service_visio' AND subkey='visioclassroom_url'";
	$res = api_sql_query($sql);
	if($res === false){$e_msg .= mysql_error($res)."<br />"; return false;}
	$sql = "DELETE FROM settings_current WHERE variable='service_visio' AND subkey='visio_is_web_rtmp'";
	$res = api_sql_query($sql);
	if($res === false){$e_msg .= mysql_error($res)."<br />"; return false;}
	$sql = "DELETE FROM settings_current WHERE variable='service_visio' AND subkey='visio_rtmp_tunnel_port'";
	$res = api_sql_query($sql);
	if($res === false){$e_msg .= mysql_error($res)."<br />"; return false;}
		
	return true;
}
?>
