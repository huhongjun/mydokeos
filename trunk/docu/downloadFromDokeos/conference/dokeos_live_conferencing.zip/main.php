<?php 
//----------------------------------------------------------------------------------------------------
// main.php 
//
// Company :  Dokeos
// Author: Laurent Dobritch
// February - May 2005
//----------------------------------------------------------------------------------------------------
session_start(); 

$_SESSION['onetoone'] = $_GET['onetoone'];
$_SESSION['master'] = $_GET['master'];
$_SESSION['room'] = $_GET['room'];
$_SESSION['numRoom'] = $_GET['numRoom'];

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
<title>Dokeos Live Conferencing</title>
</head>

<div align="center">
<frameset rows="*" cols="<? if ($_SESSION['onetoone']== "yes") echo '225'; else echo '167'; ?>,*" framespacing="0" frameborder="no"  bordercolor="#000000">
  <frame src="left.php" name="leftFrame" scrolling="NO" noresize>
  <frameset rows="510,*<? //if ($_SESSION['onetoone']== "no" && $_SESSION['master'] == "yes") echo '193'; else if($_SESSION['onetoone']== "no") echo '177'; else echo '165';?>" cols="*" framespacing="0" frameborder="no"  bordercolor="#000000">
    <frame src="centerUp.php" name="mainFrame">
    <frame src="centerDown.php" name="bottomFrame">
  </frameset>
</frameset>
</div>
<noframes><body>
</body></noframes>
</html>
