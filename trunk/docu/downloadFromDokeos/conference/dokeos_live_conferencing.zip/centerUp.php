<?php
//----------------------------------------------------------------------------------------------------
// centerUp.php - Dokeos Live Conferencing
//
// Company :  Dokeos
// Author: Laurent Dobritch
// February - May 2005
//----------------------------------------------------------------------------------------------------
?>
<?php session_start(); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
</head>

<body>
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="730" height="480">
  <param name="movie" value="center.swf?<? if (isset($_GET['image'])) echo 'image='.$_GET['image'].'&pseudo='.$_GET['pseudo'].'&master='.$_GET['master'].'&webRoot='.$_GET['webRoot']; 
											else { echo 'master='.$_SESSION['master'].'&pseudo='.$_SESSION['login'].'&firstTime=yes'.'&webRoot='.$_SESSION['webRoot']; }?>"> 
  <param name="quality" value="high">
  <embed src="center.swf?<? if (isset($_GET['image'])) echo 'image='.$_GET['image'].'&pseudo='.$_GET['pseudo'].'&master='.$_GET['master'].'&webRoot='.$_GET['webRoot']; 
							else { echo 'master='.$_SESSION['master'].'&pseudo='.$_SESSION['login'].'&firstTime=yes'.'&webRoot='.$_SESSION['webRoot']; }?>" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="730" height="480"></embed>
</object>
</body>
</html>
