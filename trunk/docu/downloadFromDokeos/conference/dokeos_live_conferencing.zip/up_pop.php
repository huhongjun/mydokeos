<?php
//----------------------------------------------------------------------------------------------------
// up_pop.php - Dokeos Live Conferencing
//
// Company :  Dokeos
// Author: Laurent Dobritch
// February - May 2005
//----------------------------------------------------------------------------------------------------
?>
<html>
<head>
<title>Upload</title>
</head>
<body>
<form name='ton_form' enctype='multipart/form-data' method='post' action='upload.php' target='frame_upload' style='width: 100%; height: 100px; text-align: center;'>
<input type='file' name='fichier' id='fichier' size='20' />
<input type='Hidden' name='login'  value='<? echo $_GET['login'] ?>' />
<br /><br /><input type='submit' name='up' value='upload' />
</form>
</body>
</html>