<?php
//----------------------------------------------------------------------------------------------------
// centerDown.php - Dokeos Live Conferencing
//
// Company :  Dokeos
// Author: Laurent Dobritch
// February - May 2005
//----------------------------------------------------------------------------------------------------
?>
<?php session_start(); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
<script type="text/javascript">
<!--
var IE5 = (document.all && parseFloat(navigator.appVersion.split("MSIE")[1])>=5.5)? true : false;
var IE6 = (document.all && parseFloat(navigator.appVersion.split("MSIE")[1])>=6)? true : false;
var Saf = (navigator.userAgent.indexOf('Safari') != -1)? true: false;
var NS = (!Saf && document.getElementById && navigator.appName.indexOf("Netscape")>=0)? true: false;
var NS7 = (NS && parseFloat(navigator.appVersion)>=5)? true: false;
var Moz = (NS && navigator.userAgent.indexOf("Netscape")<0)? true: false;
var FireFox = (navigator.userAgent.indexOf("Firefox")!=-1)  ? true:false;
var F_B = (Moz && navigator.userAgent.indexOf('Firebird') != -1)? true: false;
var mov = ((!document.all || IE5) && (!NS || NS7 || Moz))? true: false;
var ec = 2;
var btx; var bty; var btx2; var bty2;

function coord(btn_x, btn_y, btn_w, btn_h)
{
	f_form = document.getElementById("ton_form");
	parc = document.getElementById("fichier");
	swf = document.getElementById("upload");
	if(IE5 && !IE6){
		ec = 5;
	}
	btx = btn_x+swf.offsetLeft;
	bty = btn_y+swf.offsetTop;
	btx2 = btx+btn_w + ec;
	bty2 = bty+btn_h + ec;
}

function move(xy) 
{
	f_form = document.getElementById("ton_form");
	parc = document.getElementById("fichier");
	swf = document.getElementById("upload");
	if(IE5){
		x = event.x+document.body.scrollLeft;
		y = event.y+document.body.scrollTop;
	}
	else{
		x = xy.pageX;
		y = xy.pageY;
	}
	if(x>btx && x<btx2 && y>bty && y<bty2)
	{
		if(IE5)swf.SetVariable('btn_over', 1);
		parc.style.cursor = "hand";
		f_form.style.left=x-130;
		f_form.style.top=y-15;
	}
	else{
		if(IE5)swf.SetVariable('btn_over', 0);
		f_form.style.left=-500;
		f_form.style.top=-500;
	}
}


function upload()
{
	f_form.submit();
}

function flash_roll()
{
	f_form.style.left=btx;
	f_form.style.top=bty;
}

function click_change()
{
	upload();
}

if (mov)document.onmousemove = move;

//-->
</script>

</head>
<body topmargin="0" marginheight="0">
<script type="text/javascript">
<!--
if(Moz) act_file = "onClick";
else act_file = "onChange";

document.write("<form id='ton_form' enctype='multipart/form-data' method='post' action='upload.php' target='frame_upload' style='z-index: 5; position:absolute; top:-500px; left:-500px; filter: alpha(opacity=0); opacity: 0; -moz-opacity: 0;'>");
document.write("<input type='file' name='fichier' id='fichier' size='10' " + act_file + " = 'javascript:click_change();' />");
document.write("<input type='Hidden' name='login'  value='<? echo $_SESSION['login'] ?>' />");
document.write("</form>");
//-->
</script>

<iframe src="" name="frame_upload" width="50" height="50" frameborder="0" scrolling="no" style="position:absolute; top:-600px; left:-600px;"></iframe>

<? if ($_SESSION['master'] == "yes")
{
	require("database/db_tools.php");
?>
<script type="text/javascript">
<!--
verIE="";
if(IE5) verIE="&nav=IE5";
document.write('<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="730" height="187" id="upload" align="middle" style="position: absolute;">');
document.write('<param name="movie" value="downBar.swf<? echo '?pseudo='.$_SESSION['login'].'&onetoone='.$_SESSION['onetoone'].'&webRoot='.$_SESSION['webRoot']; getFilesFromDB($_SESSION['login']); ?>" />');
document.write('<param name="menu" value="false" />');
document.write('<param name="quality" value="high" />');
document.write('<param name="bgcolor" value="#ffffff" />');
document.write('<param name="wmode" value="transparent" />');
document.write('<param name="salign" value="t" />');
document.write('<param name=FlashVars value="js=ok'+verIE+'" />');
document.write('<embed src="downBar.swf<? echo '?pseudo='.$_SESSION['login'].'&onetoone='.$_SESSION['onetoone'].'&webRoot='.$_SESSION['webRoot']; getFilesFromDB($_SESSION['login']); ?>" FlashVars="js=ok" menu="false" salign="t" quality="high" bgcolor="#ffffff" width="730" height="187" name="upload" id="upload" align="middle" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer">');
document.write('</embed></object>');
//-->
</script>

<? } else { ?>

<script type="text/javascript">
<!--
document.write('<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="730" height="160" id="upload" align="middle" style="position: absolute;">');
document.write('<param name="movie" value="downBarChat.swf<? echo '?pseudo='.$_SESSION['login'].'&webRoot='.$_SESSION['webRoot']; ?>" />');
document.write('<param name="menu" value="false" />');
document.write('<param name="quality" value="high" />');
document.write('<param name="bgcolor" value="#ffffff" />');
document.write('<embed src="downBarChat.swf<? echo '?pseudo='.$_SESSION['login'].'&webRoot='.$_SESSION['webRoot'];?>"  quality="high" bgcolor="#ffffff" width="730" height="160" name="upload" id="upload" align="middle" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer">');
document.write('</embed></object>');
//-->
</script>

<? } ?>
</body>
</html>
