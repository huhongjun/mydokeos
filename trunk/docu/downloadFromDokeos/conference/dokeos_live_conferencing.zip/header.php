<?php 
//----------------------------------------------------------------------------------------------------
// header.php - Dokeos Live Conferencing
//
// Company :  Dokeos
// Author: Laurent Dobritch
// February - May 2005
//----------------------------------------------------------------------------------------------------
?>
<table align="center"  width="700" cellpadding="0" cellspacing="0" bgcolor="white">
<tr>
	<td align="left" width="500">
		<DIV style="BACKGROUND-POSITION-Y: top; BACKGROUND-IMAGE: url(../images/dokdegrade.gif); BACKGROUND-REPEAT: repeat-x; HEIGHT: 36px" align="left">
			<div style="BACKGROUND: url(../images/dokdegrade-l2.gif) no-repeat left top; FLOAT: left; WIDTH: 9px; HEIGHT: 10px" />
		</DIV>
		<font size="4" color="white">&nbsp;dokeos</font>&nbsp;<IMG title=dokeos style="WIDTH: 17px; HEIGHT: 17px" alt=dokeos src="http://www.dokeos.com/images/logo-dokeos.gif" align=middle border=0>&nbsp;&nbsp;<font size="3" color="#FFFFFF"><b><i>live conferencing</i></b></font>
	</td>
	<td align="left" width="200">
		<DIV style="BACKGROUND-POSITION-Y: top; BACKGROUND-IMAGE: url(http://www.dokeos.com/images/dokdegrade.gif); BACKGROUND-REPEAT: repeat-x; HEIGHT: 36px" align="left">
			<div style="BACKGROUND: url(../images/dokdegrade-r2.gif) no-repeat right top; FLOAT: right; WIDTH: 9px; HEIGHT: 10px" />
		</DIV>
	</td>
</tr>
</table>
<table width="700" align="center" bgcolor="white" cellpadding="5">
