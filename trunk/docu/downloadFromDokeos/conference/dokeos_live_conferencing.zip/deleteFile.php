<?php
//----------------------------------------------------------------------------------------------------
// deleteFile.php - Dokeos Live Conferencing
//
// Company :  Dokeos
// Author: Laurent Dobritch
// February - May 2005
//----------------------------------------------------------------------------------------------------

require("database/db_tools.php");

deleteFileFromDB($_GET['fileName'], $_GET['login']);

?>
