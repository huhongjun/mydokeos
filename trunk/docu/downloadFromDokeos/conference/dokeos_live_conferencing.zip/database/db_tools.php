<?php
//----------------------------------------------------------------------------------------------------
// db_tools.php - Dokeos Live Conferencing
//
// Company : Dokeos
// Author : Laurent Dobritch
// February - May 2005
//----------------------------------------------------------------------------------------------------
require_once("connect.php");

function authentification($login, $pass)
{
	$pseudo = strToUpper($login);
	$result = mysql_query("SELECT * FROM Person WHERE Pseudo='$pseudo' AND Password='$pass'");
	if ($result)
	{
	 	if (mysql_num_rows($result) > 0) return TRUE; 
	}
	return FALSE;
}

function nicknameExist($login)
{
	$pseudo = strToUpper($login);
	$result = mysql_query("SELECT * FROM Person WHERE Pseudo='$pseudo'");
	if ($result)
	 	if (mysql_num_rows($result) > 0) return TRUE; 
	return FALSE;
}

function insertSubscribeIntoDB($lastname, $firstname, $email, $login, $password, $picture)
{
	$pseudo = strToUpper($login);
	mysql_query("INSERT INTO Person(Pseudo, LastName, FirstName, Email, Password, Photo, RoomId) VALUES ('$pseudo','$lastname','$firstname','$email','$password','$picture', -1)");
}

function getFilesFromDB($login)
{
	$pseudo = strToUpper($login);
	$result = mysql_query("SELECT FileName FROM Documents JOIN Person ON Documents.IdPerson = Person.Id WHERE Pseudo='$pseudo' ORDER by Documents.Id");
	
	$i = 0;
	while ($file = mysql_fetch_object($result))
	{
		echo "&arg".$i."=". urlencode(utf8_encode($file->FileName));
		$i++; 
	}
}

function insertIntoDB($fileName, $login)
{
	$pseudo = strToUpper($login);
	$result = mysql_query("SELECT Id FROM Person WHERE Pseudo='$pseudo'");
	$person = mysql_fetch_object($result);
	mysql_query("INSERT INTO Documents(FileName,IdPerson) VALUES ('$fileName','$person->Id')");
}


function deleteFileFromDB($fileName, $login)
{
	$pseudo = strToUpper($login);
	$result = mysql_query("SELECT Id FROM Person WHERE Pseudo='$pseudo'");
	$person = mysql_fetch_object($result);
	mysql_query("DELETE FROM Documents WHERE  FileName = '$fileName' AND IdPerson= '$person->Id'");
}

function changeNbPeopleInRoom($login, $numRoom, $action)
{
	$pseudo = strToUpper($login);
	$result = mysql_query("SELECT NbPersons FROM Room WHERE Id = '$numRoom'");
	$res = mysql_fetch_object($result);
	if ($action = "add")	$nb = $res->NbPersons + 1;
	else $nb = $res->NbPersons - 1;
	mysql_query("UPDATE Room SET NbPersons = $nb WHERE Id = '$numRoom'");
}
?>
