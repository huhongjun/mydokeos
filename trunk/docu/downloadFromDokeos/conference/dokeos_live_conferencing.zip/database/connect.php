<?php
//----------------------------------------------------------------------------------------------------
// connect.php - Dokeos Live Conferencing
//
// Soci�t� : Dokeos
// Auteur : Laurent Dobritch
// F�vrier - Mai 2005
//----------------------------------------------------------------------------------------------------

define('NAME','root');
define('PASS','');
define('SERVER','127.0.0.1');
define('BASE','liveconferencing');

$connection = mysql_connect(SERVER, NAME, PASS);

if (! $connection)
{
	echo "Connection to the database has failed (1)\n";
	exit;
}
if (! mysql_select_db (BASE, $connection))
{
	echo "Connection to the database has failed (2)\n";
	exit;
}

?>
