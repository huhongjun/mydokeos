<?php
//----------------------------------------------------------------------------------------------------
// profile.php - Dokeos Live Conferencing
//
// Company :  Dokeos
// Author: Laurent Dobritch
// February - May 2005
//----------------------------------------------------------------------------------------------------
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<?php
require("database/connect.php");

$pseudo = strToUpper($_GET['name']);
$query = mysql_query("SELECT * FROM Person WHERE Pseudo='$pseudo'");
$result = mysql_fetch_object($query)
?>

<title><?php echo $_GET['name']?></title>
</head>
<body>
<table>
<tr>
	<td><img src="<?php echo 'profiles/'.$result->Photo;?>" width="86" height="96" /></td>
	<td>
		<?php
			echo "<font size='2' face='Verdana'><b>".$result->FirstName . "  " . $result->LastName . "</b></font>";
			echo "<br><br>";
			echo "<font size='2' face='Verdana'><a href='mailto:". $result->Email . "'>".$result->Email. "</a></font>";
		?>
	</td>
</tr>
</table>
</body>
</html>
