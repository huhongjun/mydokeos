<?php 
//----------------------------------------------------------------------------------------------------
// footer.php - Dokeos Live Conferencing
//
// Soci�t� : Dokeos
// Auteur : Laurent Dobritch
// F�vrier - Mai 2005
//----------------------------------------------------------------------------------------------------
?>

<tr><td colspan="2">
	<table width="100%">
		<tr><td><hr align="center" size="1" noshade></td></tr>
		<tr><td align="right"><a href="mailto:info@dokeos.com">info@dokeos.com</a>  | <a href="http://www.dokeos.com/contact.php">Contact us</a></td></tr>
	</table>
</td></tr>
</table>