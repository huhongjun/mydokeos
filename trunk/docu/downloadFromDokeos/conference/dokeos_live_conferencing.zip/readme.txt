//---------------------------------------------------------------------------------
//  Dokeos Live Conferencing - Readme
//   
//  Made by Laurent Dobritch
//---------------------------------------------------------------------------------

English

Requirements to install Dokeos Live Conferencing :

- A Macromedia Flash Communication Server 1.5
- A Webserver + PHP 4/MySQL
- GD Library for PHP


Installation steps :

1. Extract all files in the root directory or another directory of your webserver. (for example with easyPHP, the root is "C:\Program Files\EasyPHP1-7\www\")

2. Move dokeos_oto1/, dokeos_oto2/ and dokeos_oto3/  in the directory "applications/" of your Flashcomm server.

3. Change the webroot in index.php :  $_SESSION['webRoot'] = "http://localhost/"; (if you are in local).

4. Change the flachcomm root in index.php :  $_SESSION['falshcommRoot'] = "rtmp://localhost/"; (if you are in local).

5. Change database settings in connect.php.






Fran�ais

El�ments requis pour installer Dokeos Live Conferencing :

- Un serveur Flash Communication server Mx 1.5
- Un serveur web + PHP 4/MySQL
- La libraire grahpique GD pour PHP


Etapes d'installation :

1. Extraire l'enssemble des fichiers dans le r�pertoire racine ou un r�pertoire quelconque de votre serveur web. (sous easyphp par exemple la racine est "C:\Program Files\EasyPHP1-7\www\") 

2. D�placer les r�pertoires dokeos_oto1/, dokeos_oto2/ et dokeos_oto3/ dans le r�pertoire "application/" de votre serveur Flashcomm.

3. Modifier la racine de votre site web dans index.php :  $_SESSION['webRoot'] = "http://localhost/"; (si vous �tes en local).

4. Modifier la racine de votre serveur Flashcomm dans index.php :  $_SESSION['webRoot'] = "rtmp://localhost/"; (si vous �tes en local).

5. Modifier les param�tres de connexion � la base de donn�es dans connect.php.




