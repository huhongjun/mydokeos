<?php 
//----------------------------------------------------------------------------------------------------
// index.php - Dokeos Live Conferencing
//
// Company :  Dokeos
// Author: Laurent Dobritch
// February - May 2005
//----------------------------------------------------------------------------------------------------

session_start(); 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta HTTP-EQUIV="Pragma" CONTENT="no-cache">

<script language="javascript" type="text/javascript"> 

function validForm(form)
{
	if (form.login.value == "") 
    {
	   alert("Please fill the field 'login'");
		return false;
	}
	else if (form.pass.value == "") 
    {
	   alert("Please fill the field 'password'");
		return false;
	}
	else return true;
}
</script>
<title>Dokeos Online Conferencing</title>
</head>

<body background="http://www.dokeos.com/new2/images/fondligne.gif">
<?php 
include("header.php");
require("database/db_tools.php");

if (isSet($_POST['login']) && authentification($_POST['login'], $_POST['pass'])):

	if (!isSet($_SESSION['login']))
	{
		$_SESSION['login'] = urlencode(utf8_encode($_POST['login']));
		
		//------  URL web server ------
		$_SESSION['webRoot'] = "http://localhost/dokeos/";
		
		//------  URL flash server ------
		$_SESSION['flashcommRoot'] = "rtmp://localhost/";
	}
	echo "<META HTTP-EQUIV='Refresh' CONTENT='0; URL=". $_SESSION['webRoot'] ."rooms.php'>";
	
else: 
?>
<tr><td colspan="2"><a href="../index.php">dokeos</a> > live conferencing</td></tr>
<tr>
	<td>
		<table width="95%" cellpadding="5"  align="center">
		<tr><td><h4>Welcome to Dokeos Live conferencing</h4></td></tr>
		<tr><td>Dokeos only provides the most usefull features: </td></tr>
		<tr><td>
		<ul>
			<li>registration </li>
			<li>room booking </li>
			<li>audio & video </li>
			<li>slideshow </li>
			<li>whiteboard </li>
			<li>web applications and pages </li>
		</ul>
		</td></tr>
		</table>
	</td>
	<td align="right">
		<img src="images/conference.jpg">&nbsp;&nbsp;
	</td>
</tr>
<tr><td colspan="2" background="images/degradebar.gif"><b><font color="#FFFFFF">Menu</font></b> <br></td></tr>
<tr>
<td>
	<table width="280" cellpadding="20" background="images/bgForm.gif">
	<tr><td>
		<table align="center">
		<!-- formulaire d'authentification -->
		<form name="mainForm" action="index.php" method="post" >
			<tr><td><b>Login</b> </td><td><input name="login" type="text"></td></tr>
			<tr><td><b>Password</b> </td><td><input name="pass" type="password"></td></tr>
			<tr><td colspan="2" align="right"><br>
			<?php if (isSet($_POST['login'])) echo "<font color='#FF0000'>Authentification error</font> &nbsp;&nbsp;"; ?>
			<input value="enter" type="submit" onClick="return validForm(this.form)"></td></tr>
		</form>
		</table>
	</td></tr>
	</table>
</td>
<td >
	<table>
	<tr>
		<td width="170">&nbsp;</td>
		<td>
			<a href="subscribe.php">Subscription</a><br>
		</td>
	</tr>
	</table>
</td>
</tr>
<tr><td colspan="2"  background="images/degradebar.gif"><b><font color="#FFFFFF">Requirements to use Dokeos Live Conferencing</font></b> <br></td></tr>
<tr><td colspan="2">
	<table width="95%" cellpadding="5" align="center">
		<tr><td><b>PC : </b>Pentium III or equivalent, 128 mo RAM</td></tr>
		<tr><td><b>OS : </b>Windows 9x/ME/NT/2000/XP, Linux, Mac OS X </td></tr>
		<tr><td><b>Internet Connection : </b>ADSL or + internet connection </td></tr>
	</table>
</td></tr>
<tr><td colspan="2">
	<table width="95%"  cellpadding="5" align="center"><tr>
		<td width="50"><img src="images/headset.jpg" border="1" alt="headset"/></td>
		<td width="100">headset</td>
		<td width="50"><img src="images/webcam.jpg" border="1" alt="webcam"/></td>
		<td >webcam</td>
	</tr></table>
</td></tr>
<tr><td colspan="2" >
	<table width="95%" cellpadding="5"  align="center"><tr>
		<td width="10%"><a href="http://www.macromedia.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash"><img src="images/flashplayer.gif" alt="Flash Player" border="0"/></a></td>
		<td width="90%">Macromedia Flash� Player 7</td>
	</tr></table>
</td></tr>

 
<?php 
endif; 
include("footer.php");
?>
</body>
</html>
