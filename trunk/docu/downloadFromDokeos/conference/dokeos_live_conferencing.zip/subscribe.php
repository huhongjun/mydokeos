<?php
//----------------------------------------------------------------------------------------------------
// subscribe.php - Dokeos Live Conferencing
//
// Company :  Dokeos
// Author: Laurent Dobritch
// February - May 2005
//----------------------------------------------------------------------------------------------------
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Dokeos live conferencing</title>
<script language="JavaScript" type="text/javascript">
function validEmail(email)
{
   var cpt=0;
   for (i=0; i < email.value.length; i++)
   		if (email.value.charAt(i) == '@' ){ cpt++;  break; }
		
   for (; i < email.value.length; i++)
		if (email.value.charAt(i)== '.')  { cpt++;  break; }
		
   if (cpt < 2) {
   		alert("Incorrect email address");
		return false;
   }
   else return true;
}

function validForm(form)
{
	if (form.firstname.value == "") 
	{
		alert ("Please fill the field 'Firstname'");
		return false;
	}
	if (form.lastname.value == "") 
	{
		alert ("Please fill the field 'Lastname'");
		return false;
	}
	if (form.email.value == "") 
	{
		alert ("Please fill the field 'Email'");
		return false;
	}
	if (form.nickname.value == "") 
	{
		alert ("Please fill the field 'Nickname'");
		return false;
	}
	if (form.password.value == "") 
	{
		alert ("Please fill the field 'Password'");
		return false;
	}
	if (form.confirmPassword.value == "") 
	{
		alert ("Please fill the field 'Confirm password'");
		return false;
	}
	if (form.password.value != form.confirmPassword.value)
	{
		alert ("incorrect password");
		return false;
	}
	if (!validEmail(form.email)) return false;
}

</script>	
</head>

<body background="http://www.dokeos.com/new2/images/fondligne.gif">
<?php
include("header.php");
require("database/db_tools.php");
if (isSet($_POST['firstname']) && !nicknameExist($_POST['nickname'])):

	function getExtension($chaine)
	{	
		$taille = strlen($chaine)-1;
		for ($i = $taille; $i >= 0; $i--)
			if ($chaine["$i"] == '.') break;
			
		return substr($chaine, $i+1, strlen($chaine)-($i+1));
	}

	$picture = " ";
	if (isSet($_FILES['picture']))
	{
		$nom_fichier = $_FILES['picture']['tmp_name'];
		$nom_destination = getcwd() . "/profiles/" .'profile_'.$_POST['nickname'].'.'.getExtension($_FILES['picture']['name']);
		move_uploaded_file($nom_fichier, $nom_destination);
		$picture = 'profile_'.$_POST['nickname'].'.'.getExtension($_FILES['picture']['name']);
	}
	insertSubscribeIntoDB($_POST['lastname'], $_POST['firstname'], $_POST['email'], $_POST['nickname'], $_POST['password'], $picture);

	echo "<tr><td>";
	echo "<table cellpadding='20' background='images/bgSubscribe.gif' align='center' width='475'><tr><td height='358' align='center'>";
    echo "Subscription complete<br><br>	<a href='index.php'>login page</a>";
	echo "</td></tr></table>";
	echo "</td></tr>";
	
else: 
?>
<tr><td colspan="2"><a href="../index.php">dokeos</a> > <a href="index.php">live conferencing</a> > subscription</td></tr>
<tr><td>
<table cellpadding="20" background="images/bgSubscribe.gif" align="center" width="475"><tr><td height="358">
	<div align="center"><h3>Subscription</h3></div>
	<?php  //nickname is already taken
		if (isSet($_POST['firstname'])) echo "<div align='center'><font color='#FF0000' face='Verdana' size='2'>Nickname is already taken</font></div>";
		else echo "<br>";
	?>
	<form action="subscribe.php" method="post" enctype="multipart/form-data">
	<table align="center">
		<tr><td>First name : </td><td><input name="firstname" type="Text" size="30"/></td></tr>
		<tr><td>Last name :</td><td><input name="lastname" type="Text" size="30"/></td></tr>
		<tr><td>E-mail address : </td><td><input name="email" type="Text" size="30"/></td></tr>
		<tr><td>Nickname : </td><td><input name="nickname" type="Text" size="20"/></td></tr>
		<tr><td>Password : </td><td><input name="password" type="Password" size="20"/></td></tr>
		<tr><td>Confirm password : </td><td><input name="confirmPassword" type="Password" size="20"/></td></tr>
		<tr><td>Your picture : </td><td><input name="picture" type="file" size="30"/></td></tr>
		<tr><td colspan="2" align="center"><br><input type="Submit" value="Subscribe" onClick="return validForm(this.form)"/></td></tr>
	</table>
	</form>
</td></tr></table>
</td></tr>
<?php  
    endif; 
	include("footer.php");
?>
</body>
</html>