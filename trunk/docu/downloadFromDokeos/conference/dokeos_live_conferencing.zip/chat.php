<?php
//----------------------------------------------------------------------------------------------------
// chat.php - Dokeos Live Conferencing
//
// Company :  Dokeos
// Author: Laurent Dobritch
// February - May 2005
//----------------------------------------------------------------------------------------------------
?>
<?php session_start(); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Chat</title>
</head>

<body>
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="730" height="170" id="downBarClient" align="middle">
<param name="allowScriptAccess" value="sameDomain" />
<param name="movie" value="downBarClient.swf?master=<? echo $_SESSION['master']; ?>&pseudo=<? echo $_SESSION['login']; ?>" />
<param name="quality" value="high" />
<param name="bgcolor" value="#ffffff" />
<embed src="downBarClient.swf?master=<? echo $_SESSION['master']; ?>&pseudo=<? echo $_SESSION['login']; ?>" quality="high" bgcolor="#ffffff" width="730" height="170" name="downBarClient" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
</object>

</body>
</html>
