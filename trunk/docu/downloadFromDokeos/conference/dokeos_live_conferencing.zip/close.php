<?php 
//----------------------------------------------------------------------------------------------------
// close.php - Dokeos Live Conferencing
//
// Company :  Dokeos
// Author: Laurent Dobritch
// February - May 2005
//----------------------------------------------------------------------------------------------------
session_start(); 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Dokeos Live Conferencing</title>
</head>

<body background="http://www.dokeos.com/new2/images/fondligne.gif">
<?php include("header.php"); ?>
<tr>
	<td><a href="../index.php">dokeos</a> > <a href="index.php">live conferencing</a> > end of the conference</td>
	<td align="right" valign="top">connected as <font color="#4171b5"><b><?php echo $_SESSION['login']?></b></font></td>
</tr>
<tr><td align="center" height="300" colspan="2">
	<b>Thank you for using Dokeos Live Conferencing</b><br><br>
	<a href="rooms.php">back to room page</a>
</td></tr>

<?php include("footer.php"); ?>
</body>
</html>