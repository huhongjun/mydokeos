<?php 
//----------------------------------------------------------------------------------------------------
// rooms.php - Dokeos Live Conferencing
//
// Company :  Dokeos
// Author: Laurent Dobritch
// February - May 2005
//----------------------------------------------------------------------------------------------------

session_start(); 
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
<title>Dokeos Online Conferencing</title>
<script language="javascript" type="text/javascript"> 

function startApp(largeur, hauteur, numRoom, roomName, o2o, master)
{
	//on centre la fen�tre
	var width = largeur;
	var height = hauteur;
	var y=(screen.height-height)/2;
	var x=(screen.width-width)/2;
	window.location.href="main.php?room="+roomName+"&onetoone="+o2o+"&master="+master+"&numRoom="+numRoom;
	//window.open('main.php?room='+roomName+'&onetoone='+o2o+'&master='+master+'&numRoom='+numRoom,'dokeosOnline','top='+y+', left='+x+', width='+width+',height='+height+', status=no, directories=no, toolbar=no, location=no, menubar=no, scrollbars=no, resizable=yes');
    //window.location.href="back.php";
	//window.open('main.php?room='+roomName+'&onetoone='+o2o+'&master='+master+'&numRoom='+numRoom,'dokeosOnline','fullscreen=yes, scrollbars=auto');
}
</script>
</head>

<body background="http://www.dokeos.com/new2/images/fondligne.gif">

<?php include("header.php"); ?>
<tr>
	<td ><a href="../index.php">dokeos</a> > <a href="index.php">live conferencing</a> > rooms</td>
	<td align="right" valign="top">connected as <font color="#4171b5"><b><?php echo $_SESSION['login']?></b></font></td>
</tr>
<tr><td colspan="2">
<table align="center" cellpadding="30" background="images/bgRoom.gif" width="358"><tr><td>
	<!--- ROOM 1 : ONE2ONE --->
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="400" height="100" id="infoRoom" align="middle">
	<param name="allowScriptAccess" value="sameDomain" />
	<param name="movie" value="infoRoom.swf?flashcommRoot=<? echo $_SESSION['flashcommRoot'] ?>&roomName=oto1&numeroRoom=1" />
	<param name="quality" value="high" />
	<param name="bgcolor" value="#ffffff" />
	<embed src="infoRoom.swf?flashcommRoot=<? echo $_SESSION['flashcommRoot'] ?>&roomName=oto1&numeroRoom=1" quality="high" bgcolor="#ffffff" width="400" height="100" name="infoRoom" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
	</object>
	<br><br><br><br>
	<!--- ROOM 2 : ONE2ONE --->
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="400" height="100" id="infoRoom" align="middle">
	<param name="allowScriptAccess" value="sameDomain" />
	<param name="movie" value="infoRoom.swf?flashcommRoot=<? echo $_SESSION['flashcommRoot'] ?>&roomName=oto2&numeroRoom=2" />
	<param name="quality" value="high" />
	<param name="bgcolor" value="#ffffff" />
	<embed src="infoRoom.swf?flashcommRoot=<? echo $_SESSION['flashcommRoot'] ?>&roomName=oto2&numeroRoom=2" quality="high" bgcolor="#ffffff" width="400" height="100" name="infoRoom" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
	</object>
	<br><br><br><br>
	<!--- ROOM 3 : ONE2ONE --->
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="400" height="100" id="infoRoom2" align="middle">
	<param name="allowScriptAccess" value="sameDomain" />
	<param name="movie" value="infoRoom2.swf?flashcommRoot=<? echo $_SESSION['flashcommRoot'] ?>&roomName=otm1&numeroRoom=3" />
	<param name="quality" value="high" />
	<param name="bgcolor" value="#ffffff" />
	<embed src="infoRoom2.swf?flashcommRoot=<? echo $_SESSION['flashcommRoot'] ?>&roomName=otm1&numeroRoom=3" quality="high" bgcolor="#ffffff" width="400" height="100" name="infoRoom2" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
	</object>
	<br><br>
</td></tr></table>
</td></tr>

<?php include("footer.php"); ?>

</body>
</html>
