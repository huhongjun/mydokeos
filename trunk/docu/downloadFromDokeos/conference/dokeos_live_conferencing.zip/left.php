<?php
//----------------------------------------------------------------------------------------------------
// left.php - Dokeos Live Conferencing
//
// Company :  Dokeos
// Author: Laurent Dobritch
// February - May 2005
//----------------------------------------------------------------------------------------------------
?>
<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
<title>leftBar</title>

<script language="javascript">
	function openProfile(name)
	{
		var y= (screen.height/2) -75;
		var x= (screen.width/2) -200;
		
		window.open('profile.php?name='+name,'TEST','top='+y+', left='+x+', width=400,height=150, status=no, directories=no, toolbar=no, location=no, menubar=no, scrollbars=no, resizable=no');
	}
	
	function closeApp()
	{
		parent.close();
	}
	
	function errorFromServer(msg)
	{
		alert(msg);
		closeApp();
	}
</script>

</head>
<body bgcolor="#ffffff">
<!--URL utilis�es dans l'animation-->
<a href="http://www.dokeos.com"></a>
<!--texte utilis� dans l'animation-->
<!--
Master
Particpants
-->

<?php if ($_SESSION['onetoone'] == "yes") { ?>
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="215" height="700" id="leftBar" align="middle">
	<param name="allowScriptAccess" value="sameDomain" />
	<param name="movie" value="leftBarOTO.swf?master=<? echo $_SESSION['master']; ?>&pseudo=<? echo $_SESSION['login'];?>&webRoot=<? echo $_SESSION['webRoot'];?>&flashcommRoot=<? echo $_SESSION['flashcommRoot'];?>&room=<? echo $_SESSION['room'];?>" />
	<param name="quality" value="high" />
	<param name="bgcolor" value="#ffffff" />
	<embed src="leftBarOTO.swf?master=<? echo $_SESSION['master']; ?>&pseudo=<? echo $_SESSION['login']; ?>&webRoot=<? echo $_SESSION['webRoot'];?>&flashcommRoot=<? echo $_SESSION['flashcommRoot'];?>&room=<? echo $_SESSION['room'];?>" quality="high" bgcolor="#ffffff" width="215" height="700" name="leftBar" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
	</object>
<? } else  { ?>
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="215" height="700" id="leftBar" align="middle">
	<param name="allowScriptAccess" value="sameDomain" />
	<param name="movie" value="leftBarOTM.swf?master=<? echo $_SESSION['master']; ?>&pseudo=<? echo $_SESSION['login']; ?>&webRoot=<? echo $_SESSION['webRoot'];?>&flashcommRoot=<? echo $_SESSION['flashcommRoot'];?>&room=<? echo $_SESSION['room'];?>" />
	<param name="quality" value="high" />
	<param name="bgcolor" value="#ffffff" />
	<embed src="leftBarOTM.swf?master=<? echo $_SESSION['master']; ?>&pseudo=<? echo $_SESSION['login']; ?>&webRoot=<? echo $_SESSION['webRoot'];?>&flashcommRoot=<? echo $_SESSION['flashcommRoot'];?>&room=<? echo $_SESSION['room'];?>" quality="high" bgcolor="#ffffff" width="215" height="700" name="leftBar" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
	</object>
<? } ?>

</body>
</html>
