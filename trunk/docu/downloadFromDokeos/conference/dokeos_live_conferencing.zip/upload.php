<?php
//----------------------------------------------------------------------------------------------------
// upload.php - Dokeos Live Conferencing
//
// Company :  Dokeos
// Author: Laurent Dobritch
// February - May 2005
//----------------------------------------------------------------------------------------------------
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>upload_infos</title>
</head>
<body>
<?php
function getExtension($chaine)
{	
	$taille = strlen($chaine)-1;
	for ($i = $taille; $i >= 0; $i--)
		if ($chaine["$i"] == '.') break;
		
	return substr($chaine, $i+1, strlen($chaine)-($i+1));
}

if (isset($_FILES['fichier']))
{
	$nom_fichier = $_FILES['fichier']['tmp_name'];
	$nom_destination = getcwd() . "/upload/" .$_FILES['fichier']['name'];
	move_uploaded_file($nom_fichier, $nom_destination);

	if (!strcmp(strToUpper(getExtension($_FILES['fichier']['name'])),"GIF"))
	{
		$image = @imagecreatefromgif($nom_destination);
		if (!$image) echo "conversion error (gif to jpg)";
		imagejpeg($image, $nom_destination);
	}
	if (!strcmp(strToUpper(getExtension($_FILES['fichier']['name'])),"JPG") || !strcmp(strToUpper(getExtension($_FILES['fichier']['name'])),"JPEG"))
	{
		$image = @imagecreatefromjpeg($nom_destination);
		if (!$image) echo "conversion error";
		imagejpeg($image, $nom_destination);
	}
	if (!strcmp(strToUpper(getExtension($_FILES['fichier']['name'])),"PNG"))
	{
		$image = @imagecreatefrompng($nom_destination);
		if (!$image) echo "conversion error";
		imagejpeg($image, $nom_destination);
	}
	
	//insert file into database
	require("database/db_tools.php");
	insertIntoDB($_FILES['fichier']['name'], $_POST['login']);
}	
?>

<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="300" height="300" id="upload" align="middle">
<param name="allowScriptAccess" value="sameDomain" />
<param name="movie" value="upload.swf?fileName=<?php echo urlencode(utf8_encode($_FILES['fichier']['name'])) ?>" />
<param name="quality" value="high" />
<param name="bgcolor" value="#ffffff" />
<embed src="upload.swf?fileName=<?php echo urlencode(utf8_encode($_FILES['fichier']['name'])) ?>" quality="high" bgcolor="#ffffff" width="300" height="300" name="upload" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
</object>

</body>
</html>
